# Bitcoin Sentiment & Trader Performance Analysis

This project analyzes the relationship between **Bitcoin market sentiment** and **historical trader performance** using Python.

---

## 📁 Folder Structure

ds_NikitaGupta/
│
├── sentiment_raw/  
│   └── bitcoin_sentiment.csv         # Cleaned sentiment dataset  
│
├── trades_raw/  
│   └── trader_data.csv               # Cleaned trades dataset  
│
├── outputs/  
│   ├── top_5_trades.csv              # Final selected trades  
│   ├── sentiment_pnl_comparison.png  # Visualization 1  
│   ├── pnl_distribution.png          # Visualization 2  
│   └── sentiment_counts.png          # Visualization 3  
│
├── notebook_1.ipynb                  # Sentiment cleaning  
├── notebook_2.ipynb                  # Merging & analysis  
├── notebook_3.ipynb                  # Visualizations  
└── README.md                         # Project documentation  

---

## ✔️ Steps Completed

1. Loaded the original sentiment & trader datasets  
2. Cleaned and formatted both datasets  
3. Normalized date formats  
4. Merged datasets using `pd.merge()`  
5. Calculated performance metrics:  
   - Avg PnL  
   - Trades count  
   - Top 5 profitable trades  
6. Generated required visualizations  
7. Saved all CSVs and images in the outputs folder  

---

## 📊 Key Insights

- Greed sentiment correlates with higher average PnL  
- Traders make more trades during Fear periods  
- Top profitable trades occurred during mixed-neutral market sentiment  

---

## ▶️ How to Run

1. Upload all files to Colab or local Jupyter Notebook  
2. Run each notebook in order:  
   - `notebook_1.ipynb`  
   - `notebook_2.ipynb`  
   - `notebook_3.ipynb`  
3. Final CSVs and images will be created inside `/outputs`

---

## 🧑‍💻 Author
**Nikita Gupta**  
MSc IT – CC–1  
